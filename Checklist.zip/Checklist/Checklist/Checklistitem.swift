//
//  Checklistitem.swift
//  Checklist
//
//  Created by Сергей Герасимов on 12.10.2022.
//

import Foundation
class CheckListItem{
    var text = ""
    var checked = false
}
